import React from "react";
import styled from "styled-components";

import PETS from "../data";
import PetCard from "../components/PetCard";

const PetGrid = () => {
  return (
    <Wrapper>
      {PETS.map((pet) => (
        <PetWrapper key={pet.id}>
          <PetCard {...pet} />
        </PetWrapper>
      ))}
    </Wrapper>
  );
};

const Wrapper = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 32px;
`;

const PetWrapper = styled.div`
  min-width: 275px;
  flex: 1;
`;

export default PetGrid;
